#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "hash.h"

#define PAR_VACIO NULL
#define MISMA_CLAVE 0
#define VACIO 0
#define FACTOR_CARGA_MAXIMA 0.7
#define CONSTATE_DE_AJUSTE 50000
#define CAPACIDAD_MINIMA 3

typedef struct par {
	char *key;
	void *value;
	bool ocupado;
} par_t;

struct hash {
	par_t **tabla;
	size_t cantidad;
	size_t capacidad;
};

size_t funcion_hash(const char *clave)
{
	size_t hash = 5381;
	int c;

	while ((c = *clave++))
		hash = ((hash << 5) + hash) + (size_t)c;

	return hash;
}

void inicializar_tabla(par_t **tabla, size_t capacidad)
{
	for (int i = 0; i < capacidad; i++) {
		tabla[i] = PAR_VACIO;
	}
}

par_t *buscar_par(hash_t *hash, const char *clave, size_t *posicion)
{
	if (!hash || !clave)
		return NULL;

	par_t *par = hash->tabla[*posicion];
	while (par) {
		if (strcmp(clave, par->key) == 0 && par->ocupado)
			return par;
		*posicion = (*posicion + 1) % hash->capacidad;
		par = hash->tabla[*posicion];
	}
	return NULL;
}

par_t *par_crear(const char *clave, void *elemento)
{
	par_t *par = calloc(1, sizeof(par_t));
	if (!par)
		return NULL;

	par->key = calloc(strlen(clave) + 1, sizeof(const char));
	if (!par->key) {
		free(par);
		return NULL;
	}

	strcpy(par->key, clave);
	par->value = elemento;
	par->ocupado = true;

	return par;
}

/*hash_t *rehash(hash_t *hash)
{
	size_t nueva_capacidad = hash->capacidad * CONSTATE_DE_AJUSTE;
	size_t capacidad_anterior = hash->capacidad;
	hash->capacidad = nueva_capacidad;

	par_t **nueva_tabla = calloc(nueva_capacidad, sizeof(par_t *));
	if (!nueva_tabla)
		return NULL;

	inicializar_tabla(nueva_tabla, hash->capacidad);
	par_t **tabla_anterior = hash->tabla;
	hash->tabla = nueva_tabla;

	for (int i = 0; i < capacidad_anterior; i++) {
		par_t *par = tabla_anterior[i];
		if (par) {
			size_t nueva_posicion =
				funcion_hash(par->key) % nueva_capacidad;
			while (hash->tabla[nueva_posicion])
				nueva_posicion =
					(nueva_posicion + 1) % nueva_capacidad;
			hash->tabla[nueva_posicion] = par;
		}
	}
	free(tabla_anterior);

	return hash;
}*/

hash_t *hash_crear(size_t capacidad)
{
	hash_t *nuevo_hash = malloc(sizeof(hash_t));
	if (!nuevo_hash)
		return NULL;

	if (capacidad <= CAPACIDAD_MINIMA) {
		nuevo_hash->tabla = malloc(50000 * sizeof(par_t *));
		if (!nuevo_hash->tabla) {
			free(nuevo_hash);
			return NULL;
		}
		inicializar_tabla(nuevo_hash->tabla, 50000);

		nuevo_hash->capacidad = 50000;
		nuevo_hash->cantidad = VACIO;
		return nuevo_hash;
	}
	nuevo_hash->tabla = calloc(50000, sizeof(par_t *));
	if (!nuevo_hash->tabla) {
		free(nuevo_hash);
		return NULL;
	}
	inicializar_tabla(nuevo_hash->tabla, 50000);

	nuevo_hash->capacidad = 50000;
	nuevo_hash->cantidad = VACIO;
	return nuevo_hash;
}

hash_t *hash_insertar(hash_t *hash, const char *clave, void *elemento,
		      void **anterior)
{
	if (!hash || !clave)
		return NULL;

	/*size_t posicion = funcion_hash(clave) % hash->capacidad;
	par_t *par = buscar_par(hash, clave, &posicion);
	if (par) {
		if (anterior)
			*anterior = par->value;
		par->value = elemento;
		return hash;
	}

	par_t *nuevo_par = par_crear(clave, elemento);
	if (!nuevo_par)
		return NULL;

	if (hash->tabla[posicion]) {
		free(hash->tabla[posicion]->key);
		free(hash->tabla[posicion]);
	}

	hash->tabla[posicion] = nuevo_par;
	hash->cantidad++;
	if (anterior)
		*anterior = NULL;

	(if (hash->cantidad / hash->capacidad >= FACTOR_CARGA_MAXIMA) {
		rehash(hash);
	}*/

	return hash;
}

void *hash_quitar(hash_t *hash, const char *clave)
{
	/*if (!hash || !clave)
		return NULL;

	size_t posicion_quitada = funcion_hash(clave) % hash->capacidad;
	par_t *par_a_quitar = buscar_par(hash, clave, &posicion_quitada);
	if (!par_a_quitar)
		return NULL;

	void *elemento_quitado = par_a_quitar->value;
	par_a_quitar->ocupado = false;
	hash->cantidad--;*/

	return NULL;
}

void *hash_obtener(hash_t *hash, const char *clave)
{
	if (!hash || !clave)
		return NULL;

	size_t posicion = funcion_hash(clave) % hash->capacidad;
	par_t *par_buscado = buscar_par(hash, clave, &posicion);
	if (!par_buscado)
		return NULL;

	return par_buscado->value;
}

bool hash_contiene(hash_t *hash, const char *clave)
{
	if (!clave || !hash)
		return false;
	size_t posicion = funcion_hash(clave) % hash->capacidad;
	return buscar_par(hash, clave, &posicion) != NULL;
}

size_t hash_cantidad(hash_t *hash)
{
	if (!hash)
		return 0;
	return hash->cantidad;
}

void hash_destruir(hash_t *hash)
{
	if (!hash)
		return;

	for (int i = 0; i < hash->capacidad; i++) {
		if (hash->tabla[i] != NULL) {
			free(hash->tabla[i]->key);
			free(hash->tabla[i]);
		}
	}
	free(hash->tabla);
	free(hash);
}

void hash_destruir_todo(hash_t *hash, void (*destructor)(void *))
{
	if (!hash || !destructor)
		return;
	for (int i = 0; i < hash->capacidad; i++) {
		if (hash->tabla[i]) {
			if (destructor && hash->tabla[i]->ocupado)
				destructor(hash->tabla[i]->value);
			free(hash->tabla[i]->key);
			free(hash->tabla[i]);
		}
	}
	free(hash->tabla);
	free(hash);
}

size_t hash_con_cada_clave(hash_t *hash,
			   bool (*f)(const char *clave, void *valor, void *aux),
			   void *aux)
{
	if (!hash || !f)
		return 0;

	size_t llamadas_a_funcion = 0;
	for (int i = 0; i < hash->capacidad; i++) {
		if (hash->tabla[i]) {
			if (hash->tabla[i]->ocupado) {
				llamadas_a_funcion++;
				if (!f(hash->tabla[i]->key,
				       hash->tabla[i]->value, aux))
					return llamadas_a_funcion;
			}
		}
	}
	return llamadas_a_funcion;
}
