#include "src/tp.h"

int main(int argc, char const *argv[])
{
	//Se recomienda pasar el archivo de texto con los pokemon como argumento al ejecutar el programa

	//crear el juego
	tp_crear(argv[1]);
	//mostrar menues
	//correr carrera
	//etc

	return 0;
}
